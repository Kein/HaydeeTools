Haydee Tools
=========
Blender an addon to Export/Import Haydee assets.

With Blender 2.80 released there where many changes.

From v1.2.0 of this addon will only work with Blender 2.80+ (and viceversa).
For Blender 2.79 download v1.0.6

- Blender 2.80 ==> v1.2.0
- Blender 2.79 ==> v1.0.6

Main Features:

more info at:
http://johnzero7.github.io/HaydeeTools/


Difuse and Emissive textures are of the common kind.<br />
Normal maps are: RRRG (B is calculated. Normals can be converted from Edith. Tool=>Import texture. Format NormalMap)<br />
Specular maps are: R=Roughness, G=Specular intensity, B=Metallic (not properly implemented in Haydee. Leave 0)<br />
